import { configureStore } from "@reduxjs/toolkit";
import Reducer from './components/Slice/Slice'
import reducerSlice from './components/Slice/Slice'
export const store = configureStore({
    reducer: {
        todo: reducerSlice
    }
})